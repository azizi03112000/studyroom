# Website LMS Siswa

Website ini adalah prototipe sistem pembelajaran untuk siswa.  
Fitur awal:
- Login siswa menggunakan NISN
- Halaman Materi
- Halaman Soal
- Riwayat Nilai
- Sistem Poin

Dibuat untuk dihosting via GitHub Pages.